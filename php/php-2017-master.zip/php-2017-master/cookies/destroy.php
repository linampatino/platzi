<?php

setcookie('count', null, time() - 1);

echo 'Destroy';