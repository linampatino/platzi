<?php

setcookie('count', '1', time() + 3600);

echo '<p>Cookies</p>';