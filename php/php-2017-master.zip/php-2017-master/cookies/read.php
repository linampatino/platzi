<?php

echo 'Cookie value: ' . $_COOKIE['count'];
