<?php

$array1 = [
    1 => 'b',
    2 => 'c',
    0 => 'a'
];

$array2 = ['a', 'b', 'c'];

var_dump($array1 == $array2);
