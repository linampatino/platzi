<?php

$result = $a ?? 'default';
var_dump($result);


