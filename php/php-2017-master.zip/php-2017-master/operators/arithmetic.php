<?php

$a = 10;
$b = 3;

$c = $a%$b;
var_dump($c);