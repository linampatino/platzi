<?php

$a = 1;

var_dump(++$a);
var_dump($a);