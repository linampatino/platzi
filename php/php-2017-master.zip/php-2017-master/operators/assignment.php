<?php

$a = 'Hello ';

$a .= 'World';
var_dump($a);