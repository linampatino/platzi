<?php

$v1 = 12;
$v2 = 15;

$result = $v1 <=> $v2;
var_dump($result);

