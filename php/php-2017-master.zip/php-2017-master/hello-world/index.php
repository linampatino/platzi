<html>
    <head>
        <title>My first script</title>
    </head>
    <body>
    <?php
        echo 'Hello World';
    ?>
    </body>
</html>