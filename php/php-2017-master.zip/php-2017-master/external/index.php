<?php

require 'functions1.php';

echo '<p>Text from index.php</p>';

sum(10, 20);