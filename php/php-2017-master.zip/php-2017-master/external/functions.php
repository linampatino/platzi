<?php

echo '<p>Text from functions.php</p>';

function sum($a, $b) {
    $result = $a + $b;
    echo '<p>Result: ' . $result . '</p>';
}