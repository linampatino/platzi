<?php

$color = 'green';

switch($color) {
    case 'blue':
        echo 'Color is blue';
        break;
    case 'red':
        echo 'Color is red';
        break;
    default:
        echo 'Other';
        break;
}