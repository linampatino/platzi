<?php

session_start();

$_SESSION['count']++;

echo '<p>Adding 1</p>';