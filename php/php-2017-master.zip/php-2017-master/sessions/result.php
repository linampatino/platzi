<?php

session_start();

echo 'Result: ' . $_SESSION['count'];