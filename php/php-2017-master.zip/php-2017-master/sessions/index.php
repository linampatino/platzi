<?php

session_start();

$_SESSION['count'] = 0;

echo '<p>Session</p>';