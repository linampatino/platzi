<?php

$arrayVar = [
    'color1' => 'red',
    'color2' => 'blue',
    3 => 'black'
];

var_dump($arrayVar['color1']);

