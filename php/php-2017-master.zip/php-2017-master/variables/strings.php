<?php

$intVar = 5;

$stringVar = "Hello " . $intVar;
echo $stringVar;