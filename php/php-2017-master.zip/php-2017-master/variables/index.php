<?php

// int
//$intVar = 1;
//var_dump($intVar);

// float
//$floatVar = 1.2;
//var_dump($floatVar);

// string
//$stringVar = 'Sample text';
//var_dump($stringVar);

// bool
//$boolVar = false;
//var_dump($boolVar);

// null
//$nullVar = null;
//var_dump($nullVar);

// array
//$arrayVar = ['valor1', 12, 1.3];
//var_dump($arrayVar);